# D6Notification
Companion App for the ATCwatch Arduino Smartwatch Firmware mainly for nRF52832

Play store: https://play.google.com/store/apps/details?id=com.atcnetz.de.notification

You can support my work via PayPal: https://paypal.me/hoverboard1 this keeps projects like this coming.

You can find the ATCwatch firmware here:
https://github.com/atc1441/ATCwatch

You can find the D6Flasher / DaFlasher code here:
https://github.com/atc1441/D6Flasher
